package com.girmiti.java;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Stream;

import com.girmiti.stream.Employee;

public class highestvalue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> empdata1=new ArrayList<Employee>();
		//empdata.add(1,"Manoj",22,"Male","Developer","01-January-2024",300000);
		empdata1.add(new Employee(1,"Manoj",22,"Male","Developer","01-January-2024",300000.0));
		empdata1.add(new Employee(2,"Yujith",24,"Male","Developer","01-January-2024",500000.0));
		empdata1.add(new Employee(3,"Raj",22,"Male","AI","01-January-2024",600000.0));  //Highest
		empdata1.add(new Employee(4,"Kumar",22,"Male","DevOps","01-January-2024",400000.0));
		empdata1.add(new Employee(5,"Kavya",21,"Female","Developer","01-January-2024",300000.0));
		//empdata1.get(4);
	//	System.out.println(empdata1.get(4));
		
		
		Stream<Double> n=empdata1.stream().map(Employee :: getSalary);
		
		Scanner b=new Scanner(System.in);

		Optional<Employee> z=empdata1.stream().sorted(Comparator.comparing(Employee :: getSalary).reversed()).skip(b.nextInt()).findFirst();
		
		
		System.out.println(z.get());

	}

}
