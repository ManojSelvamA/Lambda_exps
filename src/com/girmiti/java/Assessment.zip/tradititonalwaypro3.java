package com.girmiti.java;

public class tradititonalwaypro3 {
	public static void main(String args[]) {
		System.out.println("Once a King ".concat(" is always a King only"));
	}

}
